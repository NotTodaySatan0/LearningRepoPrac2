# Learning Log DLXV82
(p.s. looks better in dark mode, always does)
# Part 1 *DurHack 2022 19-20 Feb*

### *Project: [Spoil Wordle](https://github.com/sbarnham/spoilWordle)*

Going into Durhack I had no idea what to expect. I was not even sure that I would compete. That changed after a last minute team invite the day before from two close friends going. 

Arriving for the registration and opening key note I had several ideas of the hack I wanted to build in mind. But, instead of grabbing my team and jumping right in we decided to check out some of the lectures being given. This proved invaluable and it was after these lectures and interacting with most of the sponsors that my teams confidence began to build. 

We had two main ideas in mind at the time. First a project adding color to black and white photographs and second a project that would estimate the value of a property. To us these seemed interesting ideas but they lacked that wow factor. During this process we began to talk to many other teams about their project and ideas. We found ourselves outmatched. These were bigger teams with second and third year students with clear ideas on how they would build their projects. We barely knew what our projects were least how to make them. Still having not chosen one of our two main options, back to the drawing board. 

We found the Twilio representative the most interesting and easy to talk to. He readily answered all of our questions and the lecture and demonstration of how Twilio worked was very impressive. An idea began to blossom. At the time all of my friend, especially those studying english degrees loved a game called Wordle (A word guessing game with one unique solution for each day) We wanted to spoil the fun for them.

After some digging I found that Wordle kept their solutions (indexed by the day) in a publicly served .js file. We were in business. We made a website called SpoilWordle which allowed you to enter phone numbers and then play the Wordle of the day with the solution being sent to the entered numbers using Twilios API. The solutions would be sent via a text message as well as a phone call. The phone call was made up of three parts. First, 1 of 4 introduction were randomly selected for each phone call then the Wordle of the day would be read and finally "Never Gonna Give You Up" by Rick Astley would play if full. The introductions were recorded by myself and hosted as mp3's on Twilio allowing them to be requested and played. We also changed the voice when the Wordle of the day is read to an Australian one best fitting my South African accent. This was done in the TwiML request being sent to the Twilio API (TwiML is Twilio Markup Language, Twilio's local language) The Rick Roll done at the end of the call was also hosted by Twilio and requested the same way as the introductions.

The phone number being used to send the calls and messages was bought and included in the TwiML request sent to the Twilio API. Technically we did not own this phone number but Twilio would allow us to use it for communications. This allows Twilio to record and display the activity of the phone number on it's website. Allowing us to easily see not only the outgoing calls/messages but also the incoming ones.

I knew at the end of the Hackathon there was still a lot to learn about Twilio and a lot of functionality I had not even looked at. My goal for the next part of the project is to try and learn as much as possible about it specificity to do with responses to incoming messages and calls.

(23rd Feb)
Top 3 & Funniest Hack   | Spoil Wordle Team
-------------  | -------------
![DurHackWinners](public/DurHackWinners.jpg) | ![DurHackGitHubAccs](public/DurHackGithubAccs.jpeg) 

![DurHackTeam](public/DurHackTeam.jpg)

# Part 2 *Testing SpoilWordle* (Weeks following DurHack)
After testing the project on my friend I started seeing some of the inner working of Twilio. How better to make large quantities of calls and not have many calls fail after one does (possible use cold calling) And some of the shortfalls Twilio can have when dealing with international numbers.

Twilio when given instruction can run TwiML code (hosted by Twilio in a "TwiML Bin") when messages and phone calls are sent to numbers linked to the Twilio account. This enables much greater functionality to be added to what previously was a pretty one way communication. This can be used to send photo's and voice notes. More interestingly it can be used to create response tree's giving responses based on the messages sent.

I learned about call forwarding using Twilio a very useful tool if you do not want to publicly display your phone number. Twilio can also actually record the calls taking place. Twilio has a very user friendly drag and drop Twilio studio for those not wanting to write TwiML but it is all TwiML code being run in the studio. This is something I avoided but worth mentioning.

Something else I looked into while researching Twilio was finding information about phone numbers using OSINT Tools (A tool allowing you to find out information about phone numbers such as it's footprint on online web pages) I found it interesting checking up on the phone numbers we used for the Twilio project as we did not technically own these phone numbers.

By this stage I felt I had learned most of Twilio and it's functionality and the surrounding area. Instead of spending more time pushing forward to learn very obtuse and not as helpful part of Twilio I thought it better to switch goals.

(1st April)
# Part 3 *New Project*
### *Project: [ScheduleYouLater](https://github.com/Fa41m/ScheduleYouLater)*

This part of the project started with a new goal in mind data storage. I was quite lost again after deciding I could not go much further with communication and decided this was and important and mandatory thing for every developer to learn.

After the Hackathon and having to work with the code we created during it I had a side goal of improving my codes quality in mind. This was something that proved to be an issue not only in the Hackathon but having to work with the code afterwards. Instead of creating tons of functionality I would focus this.

Myself and one of my teammates from the Hackathon decided to work together again and teamed up to make this new project. We decided to make a calender website where events could be added to days in the calendar. These events would be stored in a JSON file and read into the calender. These events could be added as recurring events or as events for a specific day.

During this time I began to re-look at SQL something I had looked at in the past but never properly learnt. I knew I wanted to create a version of the website that worked with databases and not JSON files. And this is what I wanted to do next.

(21st April)

# Part 4 *New Project*

I created a version of the website that works with a locally stored database using JQEURY. 

I also started learning about Cookies and other means of storing data though I found I was most interested in databases. Cookies are something I found interesting but I couldn't think of a good application of them in my website. Though I did revisit them when considering making the database on the server side.

JQEURY is not something that I have worked with in the past and it is something I was somewhat hesitant in using. Though I started to learn some of the basics of it since I needed it to work with databases. I found the easiest way of doing so through JQUERY.

Ideally the database that stored everything would be held on the server side. I decided to avoid doing this for two reasons. First as I was just learning how to properly interact with databases this seemed like added complexity for not much gain, and for the project to work for multiple people, I would need two tables (One for a login table and one for the table where all calendar entries are stored, linked by a primary key) 

Since much of this was new to me I decided against this for now. As I was still focusing on improving the quality of my code this seemed like a sure fire way of ruining that. But I learnt when dealing with something new your code quality is sure to drop.

I am going to continue learning about data storage and manipulation as I believe it is something all developers must know. I am also slowly learning and will continue to learn JQUERY as I've found it very interesting and I know it is something I do have to learn as well.

(4th May)
