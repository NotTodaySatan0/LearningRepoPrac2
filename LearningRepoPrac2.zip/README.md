README:

SpoilWordle: https://github.com/sbarnham/spoilWordle

ScheduleYouLater: https://github.com/Fa41m/ScheduleYouLater